					Tema 1 MN

	In vederea rezolvarii temei "Interpolare aplicata pe imagini", am urmat pasii din scheletul de cod dat si din materialul temei postat pe Moodle.
	Am implementat cele trei metode de interpolare aplicate pe imagini, folosite pentru redimensionarea si rotirea imaginilor:
	- nearest-neighbour
	- biliniara
	- bicubica

	Cerinta 1:
- nn_2x2 = metoda nearest-neighbour pe o imagine alb-negru 2x2 
- nn_2x2_RGB = face acelasi lucru, insa pentru o imagine RGB
- nn_resize = redimensioneaza imaginea alb-negru
- nn_resize_RGB = face acelasi lucru, insa pentru o imagine RGB
	
	Cerinta 2:
- bilinear_coef = calculeaza coeficientii de interpolare biliniara intre 4
puncte
- bilinear_2x2 = metoda biliniara pe o imagine alb-negru 2x2 
- bilinear_2x2 RGB = face acelasi lucru, insa pentru o imagine RGB
- bilinear_resize = redimensioneaza imaginea alb-negru
- bilinear_resize RGB = face acelasi lucru, insa pentru o imagine RGB
- bilinear_rotate = roteste o imagine alb-negru cu unghiul dat
- bilinear_rotate RGB = face acelasi lucru, insa pentru o imagine RGB

	Cerinta 3:
- precalc_d = precalculeaza derivatele dx, dy, dxy in fiecare punct al imaginii
- bicubic_coef = calculeaza matricea A de coeficienti de interpolare bicubica intre cele 4 puncte
- bicubic_resize = redimensioneaza imaginea alb-negru 
- bicubic_resize_RGB = face acelasi lucru, insa pentru o imagine RGB

	Modificari:
Nu am adus modificari codului deoarece scheletul era bine structurat, usor de inteles. 

	Feedback:
	Dupa parerea mea, aceasta tema este foarte interesanta si foarte buna de folosit in viitor. Am putut sa aflu mai multe informatii de aceste metode de interpolare aplicata pe imagini si de pe internet pentru a le intelege. Cu siguranta, ma voi informa si in viitor despre acest subiect :).


